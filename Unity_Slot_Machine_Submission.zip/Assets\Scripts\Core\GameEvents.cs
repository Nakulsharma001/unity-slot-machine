using System;
using SlotMachine.Data;
using SlotMachine.RNG;

namespace SlotMachine.Core
{
    /// <summary>
    /// Decoupled event dispatcher (Observer Pattern).
    /// Prevents tight coupling between Core Game Logic, UI presentation, and Audio systems.
    /// </summary>
    public static class GameEvents
    {
        // Economy Events
        public static Action<int> OnBalanceUpdated;
        public static Action<int> OnBetUpdated;
        public static Action<int> OnWinAmountUpdated;

        // Spin Sequence Events
        public static Action OnSpinRequested;
        public static Action OnHandlePulled;
        public static Action OnReelsStartedSpinning;
        public static Action<int, SymbolData> OnSingleReelStopped;
        public static Action<SpinOutcome> OnAllReelsStopped;

        // Win & Celebration Events
        public static Action<SpinOutcome> OnWinCelebrationStarted;
        public static Action OnWinCelebrationEnded;
        public static Action<int> OnJackpotTriggered;

        // Bonus / Free Spins Events
        public static Action<int> OnFreeSpinsAwarded;
        public static Action<int> OnFreeSpinStarted;
        public static Action<int> OnFreeSpinsCompleted;

        // System Events
        public static Action<bool> OnControlsStateChanged;
    }
}
