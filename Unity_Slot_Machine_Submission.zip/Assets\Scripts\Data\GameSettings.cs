using UnityEngine;

namespace SlotMachine.Data
{
    /// <summary>
    /// Configuration asset containing machine timing, animation curves, and betting parameters.
    /// </summary>
    [CreateAssetMenu(fileName = "GameSettings", menuName = "Slot Machine/Game Settings", order = 3)]
    public class GameSettings : ScriptableObject
    {
        [Header("Starting Economy")]
        [Tooltip("Initial credit balance given to player.")]
        [SerializeField] private int _startingBalance = 1000;

        [Tooltip("Preset bet denominations available to cycle through.")]
        [SerializeField] private int[] _betSteps = new int[] { 10, 25, 50, 100, 200 };

        [Tooltip("Default index for bet steps on game start.")]
        [SerializeField] private int _defaultBetIndex = 0;

        [Header("Reel Animation & Physics")]
        [Tooltip("Top vertical spin velocity (pixels or units per second).")]
        [SerializeField] private float _spinSpeed = 1600f;

        [Tooltip("Base duration in seconds the first reel spins at full speed.")]
        [SerializeField] private float _baseSpinDuration = 1.4f;

        [Tooltip("Staggered delay in seconds between successive reels stopping.")]
        [SerializeField] private float _reelStopStaggerDelay = 0.45f;

        [Tooltip("Distance in units the reel recoils upwards before plunging into downward spin.")]
        [SerializeField] private float _anticipationOvershootDistance = 35f;

        [Tooltip("Duration of the anticipation wind-up animation.")]
        [SerializeField] private float _anticipationDuration = 0.2f;

        [Tooltip("Distance in units the reel overshoots downwards before snapping back into place.")]
        [SerializeField] private float _stopBounceDistance = 25f;

        [Tooltip("Duration of the elastic stop bounce settling animation.")]
        [SerializeField] private float _stopBounceDuration = 0.25f;

        [Header("Reel Dimensions")]
        [Tooltip("Vertical height between consecutive symbol centers.")]
        [SerializeField] private float _symbolHeight = 120f;

        [Tooltip("Number of visible symbol rows in the window (typically 1 for classic single-line).")]
        [SerializeField] private int _visibleRows = 1;

        [Tooltip("Total buffer symbols kept in memory per reel for seamless cyclic scrolling.")]
        [SerializeField] private int _bufferSymbolCount = 5;

        // Public getters
        public int StartingBalance => _startingBalance;
        public int[] BetSteps => _betSteps;
        public int DefaultBetIndex => _defaultBetIndex;
        public float SpinSpeed => _spinSpeed;
        public float BaseSpinDuration => _baseSpinDuration;
        public float ReelStopStaggerDelay => _reelStopStaggerDelay;
        public float AnticipationOvershootDistance => _anticipationOvershootDistance;
        public float AnticipationDuration => _anticipationDuration;
        public float StopBounceDistance => _stopBounceDistance;
        public float StopBounceDuration => _stopBounceDuration;
        public float SymbolHeight => _symbolHeight;
        public int VisibleRows => _visibleRows;
        public int BufferSymbolCount => _bufferSymbolCount;
    }
}
