using UnityEngine;
using SlotMachine.Core;
using SlotMachine.RNG;

namespace SlotMachine.Audio
{
    /// <summary>
    /// Central audio controller managing sound effects and dynamic audio feedback.
    /// Uses event subscriptions to remain decoupled from core logic and UI.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        [Header("Audio Sources")]
        [SerializeField] private AudioSource _sfxSource;
        [SerializeField] private AudioSource _loopSource;
        [SerializeField] private AudioSource _fanfareSource;

        [Header("Audio Clips")]
        [SerializeField] private AudioClip _buttonClickClip;
        [SerializeField] private AudioClip _handlePullClip;
        [SerializeField] private AudioClip _reelSpinClip;
        [SerializeField] private AudioClip _reelStopClip;
        [SerializeField] private AudioClip _winBellClip;
        [SerializeField] private AudioClip _winJackpotClip;
        [SerializeField] private AudioClip _coinCountClip;

        [Header("Settings")]
        [Range(0f, 1f)] [SerializeField] private float _masterVolume = 1.0f;
        [Range(0f, 1f)] [SerializeField] private float _sfxVolume = 1.0f;
        [SerializeField] private bool _isMuted = false;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            // Ensure AudioSources exist if not assigned in inspector
            if (_sfxSource == null) _sfxSource = gameObject.AddComponent<AudioSource>();
            if (_loopSource == null) _loopSource = gameObject.AddComponent<AudioSource>();
            if (_fanfareSource == null) _fanfareSource = gameObject.AddComponent<AudioSource>();

            _loopSource.loop = true;
        }

        private void OnEnable()
        {
            GameEvents.OnHandlePulled += PlayHandlePull;
            GameEvents.OnReelsStartedSpinning += StartReelSpinSound;
            GameEvents.OnSingleReelStopped += PlayReelStop;
            GameEvents.OnAllReelsStopped += StopReelSpinSound;
            GameEvents.OnWinCelebrationStarted += PlayWinCelebrationSound;
        }

        private void OnDisable()
        {
            GameEvents.OnHandlePulled -= PlayHandlePull;
            GameEvents.OnReelsStartedSpinning -= StartReelSpinSound;
            GameEvents.OnSingleReelStopped -= PlayReelStop;
            GameEvents.OnAllReelsStopped -= StopReelSpinSound;
            GameEvents.OnWinCelebrationStarted -= PlayWinCelebrationSound;
        }

        public void PlayButtonClick()
        {
            PlayClip(_buttonClickClip, 1.0f, Random.Range(0.95f, 1.05f));
        }

        public void PlayHandlePull()
        {
            PlayClip(_handlePullClip, 1.0f, 1.0f);
        }

        private void StartReelSpinSound()
        {
            if (_isMuted || _reelSpinClip == null) return;
            _loopSource.clip = _reelSpinClip;
            _loopSource.volume = _sfxVolume * _masterVolume * 0.7f;
            _loopSource.Play();
        }

        private void StopReelSpinSound(SpinOutcome outcome)
        {
            if (_loopSource.isPlaying)
            {
                _loopSource.Stop();
            }
        }

        private void PlayReelStop(int reelIndex, Data.SymbolData symbol)
        {
            // Pitch increases subtly with each reel (e.g. 1.0 -> 1.08 -> 1.16) for ascending anticipation!
            float pitch = 1.0f + (reelIndex * 0.08f);
            PlayClip(_reelStopClip, 1.0f, pitch);
        }

        private void PlayWinCelebrationSound(SpinOutcome outcome)
        {
            if (outcome == null) return;

            if (outcome.IsJackpot)
            {
                if (_fanfareSource != null && _winJackpotClip != null && !_isMuted)
                {
                    _fanfareSource.clip = _winJackpotClip;
                    _fanfareSource.volume = _sfxVolume * _masterVolume;
                    _fanfareSource.Play();
                }
            }
            else
            {
                PlayClip(_winBellClip, 1.0f, 1.0f);
            }
        }

        public void PlayCoinCount()
        {
            PlayClip(_coinCountClip, 0.8f, Random.Range(0.95f, 1.1f));
        }

        private void PlayClip(AudioClip clip, float volumeScale = 1.0f, float pitch = 1.0f)
        {
            if (_isMuted || clip == null || _sfxSource == null) return;
            _sfxSource.pitch = pitch;
            _sfxSource.PlayOneShot(clip, volumeScale * _sfxVolume * _masterVolume);
        }

        public void ToggleMute()
        {
            _isMuted = !_isMuted;
            if (_isMuted && _loopSource.isPlaying)
            {
                _loopSource.Stop();
            }
        }
    }
}
