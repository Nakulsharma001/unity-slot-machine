using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using SlotMachine.Audio;
using SlotMachine.Core;
using SlotMachine.RNG;

namespace SlotMachine.UI
{
    /// <summary>
    /// Modal dialog displaying high-impact celebrations for Big Wins, Jackpots, and Free Spins.
    /// Features animated numerical count-up and coin audio synchronization.
    /// </summary>
    public class WinPopupController : MonoBehaviour
    {
        [Header("UI Panels")]
        [SerializeField] private GameObject _popupRoot;
        [SerializeField] private Text _titleText;
        [SerializeField] private Text _winAmountText;
        [SerializeField] private Text _subtitleText;
        [SerializeField] private Button _collectButton;

        [Header("Animation")]
        [SerializeField] private float _countUpDuration = 1.2f;

        private Coroutine _countCoroutine;
        private int _targetWin;

        private void Awake()
        {
            if (_collectButton != null)
            {
                _collectButton.onClick.AddListener(ClosePopup);
            }
            if (_popupRoot != null)
            {
                _popupRoot.SetActive(false);
            }
        }

        private void OnEnable()
        {
            GameEvents.OnWinCelebrationStarted += ShowWinCelebration;
        }

        private void OnDisable()
        {
            GameEvents.OnWinCelebrationStarted -= ShowWinCelebration;
        }

        /// <summary>
        /// Displays the celebration dialog with custom copy according to win magnitude.
        /// </summary>
        public void ShowWinCelebration(SpinOutcome outcome)
        {
            if (outcome == null || !outcome.IsWin || outcome.TotalPayout <= 0) return;

            // Only trigger popup for major wins (e.g. 5x bet or higher, or Jackpot, or Free Spins)
            if (outcome.PayoutMultiplier < 5 && !outcome.TriggeredFreeSpins) return;

            _targetWin = outcome.TotalPayout;
            if (_popupRoot != null) _popupRoot.SetActive(true);

            // Determine celebration title
            if (outcome.IsJackpot)
            {
                if (_titleText != null) _titleText.text = "★ MEGA JACKPOT! ★";
                if (_subtitleText != null) _subtitleText.text = "LUCKY SEVENS ALIGNED!";
            }
            else if (outcome.TriggeredFreeSpins)
            {
                if (_titleText != null) _titleText.text = "★ FREE SPINS BONUS! ★";
                if (_subtitleText != null) _subtitleText.text = $"YOU WON {outcome.FreeSpinsCount} FREE SPINS (2X MULTIPLIER)!";
            }
            else if (outcome.PayoutMultiplier >= 20)
            {
                if (_titleText != null) _titleText.text = "★ BIG WIN! ★";
                if (_subtitleText != null) _subtitleText.text = $"{outcome.PayoutMultiplier}X PAYOUT!";
            }
            else
            {
                if (_titleText != null) _titleText.text = "WINNER!";
                if (_subtitleText != null) _subtitleText.text = $"{outcome.WinningSymbol.DisplayName.ToUpper()} MATCH!";
            }

            if (_countCoroutine != null) StopCoroutine(_countCoroutine);
            _countCoroutine = StartCoroutine(AnimateCountUp(_targetWin));
        }

        private IEnumerator AnimateCountUp(int targetAmount)
        {
            float elapsed = 0f;
            int currentDisplay = 0;

            while (elapsed < _countUpDuration)
            {
                elapsed += Time.deltaTime;
                float progress = elapsed / _countUpDuration;
                // Ease out quad for satisfying deceleration of numbers
                float eased = 1.0f - (1.0f - progress) * (1.0f - progress);
                currentDisplay = Mathf.RoundToInt(Mathf.Lerp(0, targetAmount, eased));

                if (_winAmountText != null)
                {
                    _winAmountText.text = $"+{currentDisplay:N0} COINS";
                }

                if (AudioManager.Instance != null && (Mathf.RoundToInt(elapsed * 20) % 2 == 0))
                {
                    AudioManager.Instance.PlayCoinCount();
                }

                yield return null;
            }

            if (_winAmountText != null)
            {
                _winAmountText.text = $"+{targetAmount:N0} COINS";
            }
        }

        public void ClosePopup()
        {
            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayButtonClick();
            }

            if (_countCoroutine != null)
            {
                StopCoroutine(_countCoroutine);
                _countCoroutine = null;
            }

            if (_popupRoot != null)
            {
                _popupRoot.SetActive(false);
            }
        }
    }
}
