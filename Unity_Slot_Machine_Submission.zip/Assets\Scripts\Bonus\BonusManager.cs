using System;
using UnityEngine;
using SlotMachine.Core;
using SlotMachine.Data;
using SlotMachine.RNG;

namespace SlotMachine.Bonus
{
    /// <summary>
    /// Manages optional creative bonus mechanics:
    /// 1. Free Spins mode with 2x Win Multiplier.
    /// 2. Wild Symbol substitutions (Lucky 7 substitutes for any symbol).
    /// </summary>
    public class BonusManager : MonoBehaviour
    {
        [Header("Bonus State")]
        [SerializeField] private bool _isInBonusMode = false;
        [SerializeField] private int _remainingFreeSpins = 0;
        [SerializeField] private int _bonusAccumulatedWin = 0;
        [SerializeField] private float _bonusMultiplier = 2.0f;

        public bool IsInBonusMode => _isInBonusMode;
        public int RemainingFreeSpins => _remainingFreeSpins;
        public int BonusAccumulatedWin => _bonusAccumulatedWin;
        public float BonusMultiplier => _bonusMultiplier;

        /// <summary>
        /// Evaluates whether a spin outcome qualifies for bonus features or wild substitutions.
        /// </summary>
        public void EvaluateBonusTriggers(SpinOutcome outcome, PaytableConfig paytable)
        {
            if (outcome == null || outcome.ReelResults.Count < 3) return;

            // Check if 3 matching symbols triggered bonus (e.g. 3 Bells)
            if (outcome.IsWin && outcome.WinningSymbol != null && outcome.WinningSymbol.TriggersBonus)
            {
                int spins = outcome.WinningSymbol.FreeSpinsAwarded > 0 ? outcome.WinningSymbol.FreeSpinsAwarded : 5;
                outcome.TriggeredFreeSpins = true;
                outcome.FreeSpinsCount = spins;
            }
        }

        /// <summary>
        /// Activates Free Spins mode.
        /// </summary>
        public void AwardFreeSpins(int count)
        {
            _isInBonusMode = true;
            _remainingFreeSpins += count;
            _bonusAccumulatedWin = 0;
            GameEvents.OnFreeSpinsAwarded?.Invoke(_remainingFreeSpins);
        }

        /// <summary>
        /// Consumes one free spin turn.
        /// </summary>
        public bool ConsumeFreeSpin()
        {
            if (_remainingFreeSpins > 0)
            {
                _remainingFreeSpins--;
                GameEvents.OnFreeSpinStarted?.Invoke(_remainingFreeSpins);
                return true;
            }

            // Bonus mode finished
            _isInBonusMode = false;
            GameEvents.OnFreeSpinsCompleted?.Invoke(_bonusAccumulatedWin);
            return false;
        }

        public void AddBonusWin(int winAmount)
        {
            _bonusAccumulatedWin += winAmount;
        }

        public void ResetBonus()
        {
            _isInBonusMode = false;
            _remainingFreeSpins = 0;
            _bonusAccumulatedWin = 0;
        }
    }
}
