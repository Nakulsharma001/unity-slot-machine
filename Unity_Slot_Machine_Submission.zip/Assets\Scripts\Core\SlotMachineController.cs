using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SlotMachine.Bonus;
using SlotMachine.Data;
using SlotMachine.Reel;
using SlotMachine.RNG;

namespace SlotMachine.Core
{
    /// <summary>
    /// Master orchestrator for the slot machine.
    /// Manages the state machine, reel coordination, player economy, RNG evaluation,
    /// winning payline detection, and payout distribution.
    /// </summary>
    public class SlotMachineController : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private GameSettings _gameSettings;
        [SerializeField] private PaytableConfig _paytableConfig;

        [Header("Reel Columns")]
        [Tooltip("The 3 reel controllers ordered left to right.")]
        [SerializeField] private List<ReelController> _reels = new List<ReelController>();

        [Header("Subsystems")]
        [SerializeField] private BonusManager _bonusManager;

        // Runtime economy
        private int _currentBalance;
        private int _currentBetIndex;
        private int _lastWinAmount;
        private SlotGameState _currentState = SlotGameState.Idle;

        // RNG Engine Strategy
        private IRandomNumberGenerator _rng;
        private SpinOutcome _currentOutcome;
        private int _reelsStoppedCount = 0;

        // Public getters
        public SlotGameState CurrentState => _currentState;
        public int CurrentBalance => _currentBalance;
        public int CurrentBet => _gameSettings != null && _gameSettings.BetSteps.Length > 0 
            ? _gameSettings.BetSteps[_currentBetIndex] 
            : 10;
        public int LastWinAmount => _lastWinAmount;
        public bool CanSpin => _currentState == SlotGameState.Idle && (_currentBalance >= CurrentBet || (_bonusManager != null && _bonusManager.IsInBonusMode));

        private void Awake()
        {
            // Initialize RNG engine (Weighted RNG for realistic casino RTP, easily swappable)
            _rng = new WeightedRNG();

            // Set up starting balance and default bet
            _currentBalance = _gameSettings != null ? _gameSettings.StartingBalance : 1000;
            _currentBetIndex = _gameSettings != null ? _gameSettings.DefaultBetIndex : 0;
            _lastWinAmount = 0;
        }

        private void Start()
        {
            // Initialize reels
            for (int i = 0; i < _reels.Count; i++)
            {
                if (_reels[i] != null)
                {
                    _reels[i].Initialize(i, _gameSettings, _paytableConfig, _rng);
                    _reels[i].OnReelStopped += HandleSingleReelStopped;
                }
            }

            // Broadcast initial economy state
            GameEvents.OnBalanceUpdated?.Invoke(_currentBalance);
            GameEvents.OnBetUpdated?.Invoke(CurrentBet);
            GameEvents.OnWinAmountUpdated?.Invoke(0);
            GameEvents.OnControlsStateChanged?.Invoke(true);
        }

        private void OnDestroy()
        {
            for (int i = 0; i < _reels.Count; i++)
            {
                if (_reels[i] != null)
                {
                    _reels[i].OnReelStopped -= HandleSingleReelStopped;
                }
            }
        }

        #region Betting Controls

        /// <summary>
        /// Increments to the next bet tier.
        /// </summary>
        public void IncreaseBet()
        {
            if (_currentState != SlotGameState.Idle) return;
            if (_bonusManager != null && _bonusManager.IsInBonusMode) return;

            int nextIndex = (_currentBetIndex + 1) % _gameSettings.BetSteps.Length;
            _currentBetIndex = nextIndex;
            GameEvents.OnBetUpdated?.Invoke(CurrentBet);
        }

        /// <summary>
        /// Decrements to the previous bet tier.
        /// </summary>
        public void DecreaseBet()
        {
            if (_currentState != SlotGameState.Idle) return;
            if (_bonusManager != null && _bonusManager.IsInBonusMode) return;

            int prevIndex = (_currentBetIndex - 1 + _gameSettings.BetSteps.Length) % _gameSettings.BetSteps.Length;
            _currentBetIndex = prevIndex;
            GameEvents.OnBetUpdated?.Invoke(CurrentBet);
        }

        /// <summary>
        /// Sets a specific bet amount directly (e.g. from preset buttons).
        /// </summary>
        public void SetBetDirect(int betAmount)
        {
            if (_currentState != SlotGameState.Idle) return;
            for (int i = 0; i < _gameSettings.BetSteps.Length; i++)
            {
                if (_gameSettings.BetSteps[i] == betAmount)
                {
                    _currentBetIndex = i;
                    GameEvents.OnBetUpdated?.Invoke(CurrentBet);
                    break;
                }
            }
        }

        #endregion

        #region Spin Execution & Orchestration

        /// <summary>
        /// Primary entry point to trigger a spin (called by Spin Button or Handle pull).
        /// </summary>
        public void TriggerSpin()
        {
            if (!CanSpin) return;

            StartCoroutine(ExecuteSpinRoutine());
        }

        private IEnumerator ExecuteSpinRoutine()
        {
            bool isFreeSpin = _bonusManager != null && _bonusManager.IsInBonusMode;

            // Economy deduction (Free spins don't cost balance)
            if (!isFreeSpin)
            {
                _currentBalance -= CurrentBet;
                GameEvents.OnBalanceUpdated?.Invoke(_currentBalance);
            }
            else
            {
                _bonusManager.ConsumeFreeSpin();
            }

            // Lock controls during spin
            _currentState = SlotGameState.PullingHandle;
            GameEvents.OnControlsStateChanged?.Invoke(false);
            GameEvents.OnWinAmountUpdated?.Invoke(0);
            GameEvents.OnSpinRequested?.Invoke();
            GameEvents.OnHandlePulled?.Invoke();

            // Wait brief moment for handle pull visual
            yield return new WaitForSeconds(0.2f);

            // Step 1: Pre-calculate outcome via RNG (Server-Authoritative design)
            _currentOutcome = GenerateOutcome();

            // Step 2: Start all reels spinning
            _currentState = SlotGameState.Spinning;
            _reelsStoppedCount = 0;
            GameEvents.OnReelsStartedSpinning?.Invoke();

            for (int i = 0; i < _reels.Count; i++)
            {
                _reels[i].StartSpin();
            }

            // Step 3: Wait for base spin duration
            yield return new WaitForSeconds(_gameSettings.BaseSpinDuration);

            // Step 4: Staggered stop sequence
            _currentState = SlotGameState.StoppingReels;
            for (int i = 0; i < _reels.Count; i++)
            {
                _reels[i].RequestStop(_currentOutcome.ReelResults[i]);
                yield return new WaitForSeconds(_gameSettings.ReelStopStaggerDelay);
            }
        }

        /// <summary>
        /// Callback received each time an individual reel finishes its bounce settle.
        /// </summary>
        private void HandleSingleReelStopped(int reelIndex, SymbolData landedSymbol)
        {
            _reelsStoppedCount++;
            GameEvents.OnSingleReelStopped?.Invoke(reelIndex, landedSymbol);

            // Once all 3 reels have fully stopped
            if (_reelsStoppedCount >= _reels.Count)
            {
                StartCoroutine(ResolveSpinOutcomeRoutine());
            }
        }

        /// <summary>
        /// Resolves win logic, applies payouts, and triggers celebrations.
        /// </summary>
        private IEnumerator ResolveSpinOutcomeRoutine()
        {
            _currentState = SlotGameState.EvaluatingWin;
            GameEvents.OnAllReelsStopped?.Invoke(_currentOutcome);

            yield return new WaitForSeconds(0.2f);

            if (_currentOutcome.IsWin)
            {
                _currentState = SlotGameState.CelebratingWin;

                // Highlight winning symbols across reels
                for (int i = 0; i < _reels.Count; i++)
                {
                    _reels[i].HighlightWinningSymbol(true);
                }

                // Credit payout to balance
                _lastWinAmount = _currentOutcome.TotalPayout;
                _currentBalance += _lastWinAmount;
                GameEvents.OnWinAmountUpdated?.Invoke(_lastWinAmount);
                GameEvents.OnBalanceUpdated?.Invoke(_currentBalance);

                if (_bonusManager != null && _bonusManager.IsInBonusMode)
                {
                    _bonusManager.AddBonusWin(_lastWinAmount);
                }

                // Check for bonus triggers
                if (_currentOutcome.TriggeredFreeSpins && _bonusManager != null)
                {
                    _bonusManager.AwardFreeSpins(_currentOutcome.FreeSpinsCount);
                }

                // Broadcast celebration event (UI will display Win Popup / Particles)
                GameEvents.OnWinCelebrationStarted?.Invoke(_currentOutcome);

                // Wait for win celebration duration before returning to idle
                float celebrationDelay = _currentOutcome.IsJackpot ? 3.0f : 1.5f;
                yield return new WaitForSeconds(celebrationDelay);

                GameEvents.OnWinCelebrationEnded?.Invoke();
            }

            // Return to Idle or continue next Free Spin
            if (_bonusManager != null && _bonusManager.IsInBonusMode && _bonusManager.RemainingFreeSpins > 0)
            {
                _currentState = SlotGameState.BonusRound;
                yield return new WaitForSeconds(0.8f);
                StartCoroutine(ExecuteSpinRoutine());
            }
            else
            {
                _currentState = SlotGameState.Idle;
                GameEvents.OnControlsStateChanged?.Invoke(true);
            }
        }

        #endregion

        #region Mathematical Evaluation & Winning Logic

        /// <summary>
        /// Generates random reel stops and evaluates win conditions according to paytable rules.
        /// </summary>
        private SpinOutcome GenerateOutcome()
        {
            List<SymbolData> reelSymbols = _rng.GenerateReelOutcomes(_reels.Count, _paytableConfig.Symbols);
            var outcome = new SpinOutcome(reelSymbols);

            EvaluateOutcome(outcome);
            return outcome;
        }

        /// <summary>
        /// Evaluates matching paylines, wild substitutions, and multiplier math.
        /// </summary>
        private void EvaluateOutcome(SpinOutcome outcome)
        {
            if (outcome.ReelResults.Count < 3) return;

            SymbolData s1 = outcome.ReelResults[0];
            SymbolData s2 = outcome.ReelResults[1];
            SymbolData s3 = outcome.ReelResults[2];

            // Rule 1: Three of a Kind (All 3 reels match)
            if (s1.Type == s2.Type && s2.Type == s3.Type)
            {
                outcome.IsWin = true;
                outcome.WinningSymbol = s1;
                outcome.PayoutMultiplier = s1.ThreeOfAKindMultiplier;
                outcome.IsJackpot = (s1.Type == SymbolType.Seven);

                if (s1.TriggersBonus)
                {
                    outcome.TriggeredFreeSpins = true;
                    outcome.FreeSpinsCount = s1.FreeSpinsAwarded > 0 ? s1.FreeSpinsAwarded : 5;
                }
            }
            // Rule 2: Wild Substitution (Seven can act as Wild if 2 matching symbols + Seven)
            else if (IsWildMatch(s1, s2, s3, out SymbolData matchedSymbol, out int wildMultiplier))
            {
                outcome.IsWin = true;
                outcome.WinningSymbol = matchedSymbol;
                outcome.PayoutMultiplier = wildMultiplier;
            }
            // Rule 3: Two matching Cherries on first 2 reels
            else if (s1.Type == SymbolType.Cherry && s2.Type == SymbolType.Cherry)
            {
                outcome.IsWin = true;
                outcome.WinningSymbol = s1;
                outcome.PayoutMultiplier = s1.TwoOfAKindMultiplier > 0 ? s1.TwoOfAKindMultiplier : 3;
            }
            // Rule 4: Single Cherry on first reel (Consolation / Return Bet)
            else if (s1.Type == SymbolType.Cherry)
            {
                outcome.IsWin = true;
                outcome.WinningSymbol = s1;
                outcome.PayoutMultiplier = 1;
            }

            // Calculate total payout with active bonus multiplier if in free spins
            if (outcome.IsWin)
            {
                float bonusMult = (_bonusManager != null && _bonusManager.IsInBonusMode) 
                    ? _paytableConfig.BonusWinMultiplier 
                    : 1.0f;

                outcome.TotalPayout = Mathf.RoundToInt(CurrentBet * outcome.PayoutMultiplier * bonusMult);
            }
        }

        private bool IsWildMatch(SymbolData s1, SymbolData s2, SymbolData s3, out SymbolData winningSymbol, out int multiplier)
        {
            winningSymbol = null;
            multiplier = 0;

            // Check if one of them is Seven (Wild) while the other two are identical non-seven symbols
            if (s1.Type == SymbolType.Seven && s2.Type == s3.Type)
            {
                winningSymbol = s2;
                multiplier = s2.ThreeOfAKindMultiplier;
                return true;
            }
            if (s2.Type == SymbolType.Seven && s1.Type == s3.Type)
            {
                winningSymbol = s1;
                multiplier = s1.ThreeOfAKindMultiplier;
                return true;
            }
            if (s3.Type == SymbolType.Seven && s1.Type == s2.Type)
            {
                winningSymbol = s1;
                multiplier = s1.ThreeOfAKindMultiplier;
                return true;
            }

            return false;
        }

        #endregion
    }
}
