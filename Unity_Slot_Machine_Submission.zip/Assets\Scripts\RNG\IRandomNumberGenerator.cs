using System.Collections.Generic;
using SlotMachine.Data;

namespace SlotMachine.RNG
{
    /// <summary>
    /// Strategy interface for slot game Random Number Generators.
    /// Decouples the randomization algorithm from the reel spinning mechanics,
    /// enabling uniform RNG, weighted RNG, or seeded mock RNG for automated testing.
    /// </summary>
    public interface IRandomNumberGenerator
    {
        /// <summary>
        /// Selects a single random symbol from the configured paytable.
        /// </summary>
        SymbolData GetRandomSymbol(IReadOnlyList<SymbolData> availableSymbols);

        /// <summary>
        /// Generates the landing outcome for all reels in a spin cycle.
        /// </summary>
        /// <param name="reelCount">Total number of spinning reels (e.g., 3).</param>
        /// <param name="availableSymbols">All registered symbol data models.</param>
        /// <returns>List of target symbols for each reel index.</returns>
        List<SymbolData> GenerateReelOutcomes(int reelCount, IReadOnlyList<SymbolData> availableSymbols);
    }
}
