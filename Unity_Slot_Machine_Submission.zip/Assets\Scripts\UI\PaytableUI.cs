using UnityEngine;
using UnityEngine.UI;
using SlotMachine.Audio;

namespace SlotMachine.UI
{
    /// <summary>
    /// Displays the game rules, symbol multipliers, and bonus feature information.
    /// Accessible via the info / paytable button.
    /// </summary>
    public class PaytableUI : MonoBehaviour
    {
        [Header("Panels")]
        [SerializeField] private GameObject _paytableModal;
        [SerializeField] private Button _openButton;
        [SerializeField] private Button _closeButton;

        private void Awake()
        {
            if (_openButton != null) _openButton.onClick.AddListener(OpenPaytable);
            if (_closeButton != null) _closeButton.onClick.AddListener(ClosePaytable);

            if (_paytableModal != null)
            {
                _paytableModal.SetActive(false);
            }
        }

        public void OpenPaytable()
        {
            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayButtonClick();
            }
            if (_paytableModal != null)
            {
                _paytableModal.SetActive(true);
            }
        }

        public void ClosePaytable()
        {
            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayButtonClick();
            }
            if (_paytableModal != null)
            {
                _paytableModal.SetActive(false);
            }
        }
    }
}
