@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0setup_git_history.ps1"
pause
