using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SlotMachine.Data;
using SlotMachine.RNG;

namespace SlotMachine.Reel
{
    /// <summary>
    /// Controls the physical animation, symbol wrapping, and stopping logic for a single slot reel column.
    /// Implements smooth acceleration, continuous cycling with object pooling, and elastic overshoot bounce.
    /// </summary>
    public class ReelController : MonoBehaviour
    {
        [Header("Configuration")]
        [Tooltip("Zero-based index of this reel column (0 = Left, 1 = Center, 2 = Right).")]
        [SerializeField] private int _reelIndex;

        [Tooltip("Prefab for instantiating symbol cells.")]
        [SerializeField] private SymbolItem _symbolPrefab;

        [Tooltip("Container holding the instantiated symbol items.")]
        [SerializeField] private RectTransform _symbolsContainer;

        [Header("Runtime References")]
        [SerializeField] private GameSettings _settings;
        [SerializeField] private PaytableConfig _paytable;

        // Internal state
        private ReelState _state = ReelState.Idle;
        private List<SymbolItem> _symbolItems = new List<SymbolItem>();
        private IRandomNumberGenerator _rng;
        private SymbolData _targetSymbol;
        private float _currentSpeed = 0f;
        private Coroutine _spinCoroutine;

        // Callbacks
        public event Action<int, SymbolData> OnReelStopped;

        public int ReelIndex => _reelIndex;
        public ReelState State => _state;
        public SymbolItem CenterSymbolItem => _symbolItems.Count > 1 ? _symbolItems[1] : null;

        public void Initialize(int index, GameSettings settings, PaytableConfig paytable, IRandomNumberGenerator rng)
        {
            _reelIndex = index;
            _settings = settings;
            _paytable = paytable;
            _rng = rng;

            SetupSymbols();
        }

        /// <summary>
        /// Populates the reel strip with symbol items and positions them vertically.
        /// Symbol 0 = Top, Symbol 1 = Center (Payline), Symbol 2 = Bottom, etc.
        /// </summary>
        private void SetupSymbols()
        {
            if (_symbolsContainer == null)
            {
                _symbolsContainer = GetComponent<RectTransform>();
            }

            // Clear any preexisting children
            for (int i = _symbolsContainer.childCount - 1; i >= 0; i--)
            {
                Destroy(_symbolsContainer.GetChild(i).gameObject);
            }
            _symbolItems.Clear();

            int totalSymbols = _settings.BufferSymbolCount;
            float symbolHeight = _settings.SymbolHeight;

            // Spawn symbol items vertically centered around Y = 0
            // Index 0: Top (+symbolHeight)
            // Index 1: Center (0) -> Target Payline
            // Index 2: Bottom (-symbolHeight)
            // Additional buffer symbols above for continuous cycling
            for (int i = 0; i < totalSymbols; i++)
            {
                SymbolItem item = Instantiate(_symbolPrefab, _symbolsContainer);
                float yPos = (1 - i) * symbolHeight;
                item.RectTransform.anchoredPosition = new Vector2(0, yPos);

                // Assign initial random symbol
                SymbolData randSymbol = _rng != null 
                    ? _rng.GetRandomSymbol(_paytable.Symbols) 
                    : _paytable.Symbols[i % _paytable.Symbols.Count];

                item.SetSymbol(randSymbol);
                _symbolItems.Add(item);
            }
        }

        /// <summary>
        /// Initiates the spinning sequence with anticipation wind-up.
        /// </summary>
        public void StartSpin()
        {
            if (_state != ReelState.Idle && _state != ReelState.Stopped) return;

            ClearHighlights();
            if (_spinCoroutine != null) StopCoroutine(_spinCoroutine);
            _spinCoroutine = StartCoroutine(SpinRoutine());
        }

        /// <summary>
        /// Commands this reel to smoothly decelerate and land on the predetermined target symbol.
        /// </summary>
        public void RequestStop(SymbolData targetSymbol)
        {
            _targetSymbol = targetSymbol;
            _state = ReelState.Stopping;
        }

        /// <summary>
        /// Coroutine driving the reel through Anticipation -> High-Speed Spin -> Deceleration -> Elastic Bounce.
        /// </summary>
        private IEnumerator SpinRoutine()
        {
            _state = ReelState.Anticipation;
            float symbolHeight = _settings.SymbolHeight;
            float totalHeight = _symbolItems.Count * symbolHeight;

            // --- Phase 1: Anticipation (Subtle upward recoil) ---
            Vector2 initialContainerPos = _symbolsContainer.anchoredPosition;
            float antTimer = 0f;
            float antDuration = _settings.AnticipationDuration;
            float antDistance = _settings.AnticipationOvershootDistance;

            while (antTimer < antDuration)
            {
                antTimer += Time.deltaTime;
                float progress = antTimer / antDuration;
                // Sine curve creates a natural mechanical pull
                float offset = Mathf.Sin(progress * Mathf.PI * 0.5f) * antDistance;
                _symbolsContainer.anchoredPosition = initialContainerPos + new Vector2(0, offset);
                yield return null;
            }

            // --- Phase 2: Full-Speed Spinning ---
            _state = ReelState.Spinning;
            float accelTimer = 0f;
            float accelDuration = 0.25f;

            while (_state == ReelState.Spinning)
            {
                // Accelerate smoothly to max spin speed
                if (accelTimer < accelDuration)
                {
                    accelTimer += Time.deltaTime;
                    _currentSpeed = Mathf.Lerp(0f, _settings.SpinSpeed, accelTimer / accelDuration);
                }
                else
                {
                    _currentSpeed = _settings.SpinSpeed;
                }

                // Scroll downward
                ScrollSymbols(_currentSpeed * Time.deltaTime, symbolHeight);
                yield return null;
            }

            // --- Phase 3: Stopping & Target Alignment ---
            // Place target symbol in the incoming buffer at top
            SymbolItem incomingItem = GetHighestSymbolItem();
            incomingItem.SetSymbol(_targetSymbol);

            // Continue scrolling until incoming target symbol reaches center position (Y = 0)
            while (incomingItem.RectTransform.anchoredPosition.y > 0)
            {
                float step = _currentSpeed * Time.deltaTime;
                ScrollSymbols(step, symbolHeight);
                yield return null;
            }

            // Lock target symbol exactly at center Y = 0
            float alignmentOffset = -incomingItem.RectTransform.anchoredPosition.y;
            AdjustAllSymbolPositions(alignmentOffset);

            // Reorder list so that incomingItem is now center index 1
            RealignSymbolList(incomingItem);

            // --- Phase 4: Elastic Overshoot & Settle Bounce ---
            _state = ReelState.OvershootBounce;
            float bounceDuration = _settings.StopBounceDuration;
            float bounceDist = _settings.StopBounceDistance;
            float bounceTimer = 0f;

            while (bounceTimer < bounceDuration)
            {
                bounceTimer += Time.deltaTime;
                float t = bounceTimer / bounceDuration;
                // Decaying damped sine wave for realistic mechanical bounce
                float bounceY = -Mathf.Sin(t * Mathf.PI) * bounceDist * (1.0f - t);
                _symbolsContainer.anchoredPosition = new Vector2(0, bounceY);
                yield return null;
            }

            _symbolsContainer.anchoredPosition = Vector2.zero;
            _state = ReelState.Stopped;

            // Notify listeners that this reel has locked in its outcome
            OnReelStopped?.Invoke(_reelIndex, _targetSymbol);
        }

        /// <summary>
        /// Moves all symbol items downwards by deltaY and wraps items exiting bottom back to top.
        /// </summary>
        private void ScrollSymbols(float deltaY, float symbolHeight)
        {
            float bottomThreshold = -2.0f * symbolHeight;
            float topY = (GetHighestSymbolItem().RectTransform.anchoredPosition.y) + symbolHeight;

            for (int i = 0; i < _symbolItems.Count; i++)
            {
                SymbolItem item = _symbolItems[i];
                Vector2 pos = item.RectTransform.anchoredPosition;
                pos.y -= deltaY;

                // Wrap-around logic: when an item falls below the visible window
                if (pos.y < bottomThreshold)
                {
                    pos.y = topY;
                    // Assign a new random symbol during continuous spin
                    if (_state == ReelState.Spinning && _rng != null)
                    {
                        item.SetSymbol(_rng.GetRandomSymbol(_paytable.Symbols));
                    }
                }

                item.RectTransform.anchoredPosition = pos;
            }
        }

        private SymbolItem GetHighestSymbolItem()
        {
            SymbolItem highest = _symbolItems[0];
            for (int i = 1; i < _symbolItems.Count; i++)
            {
                if (_symbolItems[i].RectTransform.anchoredPosition.y > highest.RectTransform.anchoredPosition.y)
                {
                    highest = _symbolItems[i];
                }
            }
            return highest;
        }

        private void AdjustAllSymbolPositions(float deltaY)
        {
            for (int i = 0; i < _symbolItems.Count; i++)
            {
                Vector2 pos = _symbolItems[i].RectTransform.anchoredPosition;
                pos.y += deltaY;
                _symbolItems[i].RectTransform.anchoredPosition = pos;
            }
        }

        private void RealignSymbolList(SymbolItem centerItem)
        {
            _symbolItems.Sort((a, b) => b.RectTransform.anchoredPosition.y.CompareTo(a.RectTransform.anchoredPosition.y));
        }

        public void HighlightWinningSymbol(bool highlight)
        {
            if (CenterSymbolItem != null)
            {
                CenterSymbolItem.SetHighlight(highlight);
            }
        }

        public void ClearHighlights()
        {
            for (int i = 0; i < _symbolItems.Count; i++)
            {
                _symbolItems[i].SetHighlight(false);
            }
        }
    }
}
