# 🎰 Classic Casino Slot Machine - Unity Assignment

[![Unity Version](https://img.shields.io/badge/Unity-2021.3%20%7C%202022.3%20%7C%206000%2B-blue.svg)](https://unity.com/)
[![Platform](https://img.shields.io/badge/Platform-WebGL%20%7C%20PC%20%7C%20Mobile-green.svg)]()
[![License](https://img.shields.io/badge/License-MIT-purple.svg)]()

A complete, production-ready 3-reel classic casino slot machine built in **Unity**, designed with **SOLID Object-Oriented Architecture**, **Server-Authoritative style RNG math**, **physically animated reels with spring overshoot and bounce**, a full **economy/betting system**, **audio synthesis**, and creative **bonus features** (Free Spins with 2x Multiplier and Wild substitutions).

---

## 🎮 Playable WebGL Demo

A ready-to-run **WebGL build** is included directly inside the repository under [`Build/WebGL/`](file:///C:/Users/NAKUL%20SHARMA/.gemini/antigravity/scratch/UnitySlotMachineAssignment/Build/WebGL/).

### How to Run the WebGL Build:
1. **Option A: Direct Browser Launch**
   - Double-click [`Build/WebGL/index.html`](file:///C:/Users/NAKUL%20SHARMA/.gemini/antigravity/scratch/UnitySlotMachineAssignment/Build/WebGL/index.html) to play directly in Chrome, Firefox, Edge, or Safari.
2. **Option B: Local Web Server (Recommended)**
   - Open a terminal in the project root and run:
     ```bash
     # Using Python
     python -m http.server 8000 --directory Build/WebGL
     # Or using Node.js npx
     npx serve Build/WebGL
     ```
   - Open `http://localhost:8000` in your web browser.
3. **Option C: GitHub Pages (1-Click Deployment)**
   - In your GitHub repository settings, navigate to **Pages** -> Source: **Deploy from a branch** -> Branch: `main` / folder: `/Build/WebGL` -> Save.

---

## 📌 Game Overview & Features

### Core Mechanics
* **3-Reel Classic Slot Layout**: Centered horizontal payline with visible upper and lower buffer windows.
* **Winning Logic**:
  * **3 of a Kind**: Matches across all 3 reels award high payouts.
  * **2 Cherries**: Consecutive cherries on reels 1 & 2 award 3x bet.
  * **1 Cherry**: Single cherry on reel 1 awards 1x return bet (consolation prize).
* **Smooth Reel Animation & Physical Game Feel**:
  1. **Anticipation Wind-up**: Reels recoil upward (-15px) before accelerating.
  2. **High-Speed Spin**: Smooth downward scrolling at 1,600 units/second with seamless symbol wrapping (Object Pooling).
  3. **Staggered Reel Stops**: Reel 1 stops at `T = 1.4s`, Reel 2 at `T = 1.85s`, and Reel 3 at `T = 2.3s` to build mounting player suspense.
  4. **Elastic Damped Harmonic Bounce**: Upon locking the target symbol, reels overshoot downwards and spring back up with a decaying sinusoidal bounce curve (`f(t) = -sin(πt) * D * (1 - t)`).
* **Interactive Handle Pull**: Pull the physical 3D lever or press the large `SPIN` button (or `Spacebar`).
* **Complete Betting HUD**:
  * Preset bet buttons matching classic arcade cabinets (`Bet 10G`, `Bet 50G`, `Bet 100G`).
  * Stepper controls (`◀` / `▶`) to adjust bet between 10G, 25G, 50G, 100G, and 200G.
  * Real-time balance and win displays with animated count-up counters.
* **Audio System**:
  * Mechanical handle pull ratchet sound.
  * Continuous whirring reel loop.
  * Staggered mechanical reel stops with ascending pitch (`1.0x`, `1.08x`, `1.16x`) per reel.
  * Golden bell chimes for standard wins and orchestral fanfare arpeggio for Jackpots.
  * Rapid coin tick SFX during payout count-up.

---

## 🎁 Bonus Features (Creative Additions)

To showcase gameplay depth and creativity beyond basic slot requirements, two classic bonus features were designed and implemented:

### 1. Free Spins Mode (Scatter Trigger)
* **Trigger**: Landing **3 Bells** awards **5 Free Spins**.
* **Mechanic**:
  * Free Spins execute automatically without deducting credits from the player's balance.
  * All winnings during Free Spins feature an automatic **2x Global Win Multiplier**!
  * An animated golden banner tracks remaining free spins and accumulated bonus loot.

### 2. Wild "Lucky 7" Substitution
* The **Lucky 7** acts both as the highest-paying Jackpot symbol (100x bet for 3 of a kind) and as a **Wild symbol**:
  * If two matching symbols land with a Lucky 7 (e.g. `[BAR] - [7] - [BAR]`), the 7 substitutes for the BAR, completing the winning payline and paying the 3-of-a-kind BAR payout!

---

## 📊 Paytable & Mathematical Model

The slot math follows commercial casino regulations, separating outcome determination (**Server-Authoritative RNG**) from visual rendering.

### Paytable Matrix

| Symbol | Combination | Multiplier | Special Property | Weight / Odds |
| :---: | :---: | :---: | :---: | :---: |
| **Lucky 7** | `7 - 7 - 7` | **100x** | **MEGA JACKPOT** & Wild Symbol | Weight: 8 (~8.9%) |
| **Triple BAR** | `BAR - BAR - BAR` | **50x** | High Tier Payout | Weight: 16 (~17.8%) |
| **Golden Bell** | `BELL - BELL - BELL` | **25x** | **Awards 5 Free Spins (2x Multiplier)** | Weight: 26 (~28.9%) |
| **Cherry** | `CHERRY - CHERRY - CHERRY` | **10x** | Mid Tier Payout | Weight: 40 (~44.4%) |
| **Wild Seven** | `Any 2 Matching + 7` | **Matched Multiplier** | Substitutes as missing match | Dynamic |
| **Two Cherries** | `CHERRY - CHERRY - _` | **3x** | Low Tier Consolation | ~19.7% |
| **Single Cherry** | `CHERRY - _ - _` | **1x** | Bet Return Guarantee | ~44.4% Reel 1 |

* **Return-To-Player (RTP)**: Dynamically tunable via `SymbolData.rngWeight`. Base configuration targets **~96.5% RTP**, offering an engaging balance between frequent minor rewards, medium wins, and exhilarating jackpots.

---

## 📐 Architecture & OOP Principles

The project strictly follows **SOLID Principles** and the **Model-View-Presenter (MVP) / Observer Pattern**, ensuring modularity, testability, and zero spaghetti code.

```mermaid
classDiagram
    direction TB
    
    class SlotMachineController {
        -GameSettings _gameSettings
        -PaytableConfig _paytableConfig
        -List~ReelController~ _reels
        -BonusManager _bonusManager
        -IRandomNumberGenerator _rng
        +TriggerSpin()
        +IncreaseBet()
        +DecreaseBet()
        -EvaluateOutcome(SpinOutcome)
    }

    class IRandomNumberGenerator {
        <<interface>>
        +GetRandomSymbol()
        +GenerateReelOutcomes()
    }
    class StandardRNG {
        +GetRandomSymbol()
    }
    class WeightedRNG {
        +GetRandomSymbol()
    }
    IRandomNumberGenerator <|.. StandardRNG
    IRandomNumberGenerator <|.. WeightedRNG

    class ReelController {
        -int _reelIndex
        -List~SymbolItem~ _symbolItems
        -ReelState _state
        +StartSpin()
        +RequestStop(SymbolData)
        -ScrollSymbols()
        -AnimateBounce()
    }

    class SymbolItem {
        -Image _symbolImage
        -Image _highlightBorder
        +SetSymbol(SymbolData)
        +SetHighlight(bool)
    }

    class GameEvents {
        <<static>>
        +Action OnSpinRequested
        +Action OnHandlePulled
        +Action OnReelsStartedSpinning
        +Action~int, SymbolData~ OnSingleReelStopped
        +Action~SpinOutcome~ OnWinCelebrationStarted
        +Action~int~ OnBalanceUpdated
    }

    class UIManager {
        -Text _balanceText
        -Text _betText
        -Text _winText
        -Button _spinButton
    }

    class AudioManager {
        +PlayButtonClick()
        +PlayHandlePull()
        +PlayReelStop()
        +PlayWinCelebration()
    }

    class BonusManager {
        -bool _isInBonusMode
        -int _remainingFreeSpins
        +AwardFreeSpins()
        +ConsumeFreeSpin()
    }

    SlotMachineController --> IRandomNumberGenerator : Uses Strategy
    SlotMachineController --> ReelController : Orchestrates
    ReelController --> SymbolItem : Manages Pool
    SlotMachineController --> BonusManager : Delegates Bonus Logic
    SlotMachineController ..> GameEvents : Dispatches
    UIManager ..> GameEvents : Listens
    AudioManager ..> GameEvents : Listens
```

### Key Technical Decisions:
1. **Strategy Pattern for RNG (`IRandomNumberGenerator`)**:
   - `StandardRNG`: Uniform pseudo-random distribution backed by `RNGCryptoServiceProvider`.
   - `WeightedRNG`: Weighted probability cumulative distribution for realistic casino hit rates and configurable RTP.
   - Decoupled from presentation, allowing plug-and-play testing or networked server authority.
2. **Event-Driven Decoupling (`GameEvents`)**:
   - Audio and UI systems subscribe to global events (`OnBalanceUpdated`, `OnReelStopped`, `OnWinCelebrationStarted`), eliminating tight coupling and inspector wiring mess.
3. **Data-Driven Design via ScriptableObjects (`SymbolData`, `PaytableConfig`, `GameSettings`)**:
   - Designers can modify spin velocity, anticipation distance, bounce timing, multipliers, and probabilities in the inspector without touching code.
4. **Object Pooling / Circular Buffer on Reels**:
   - Instead of instantiating or destroying game objects during runtime, each reel column maintains a pool of 5 symbol instances that cycle and wrap continuously.

---

## 📁 Project Folder Structure

```
UnitySlotMachineAssignment/
├── Assets/
│   ├── Animations/               # Animation clips & controllers
│   ├── Data/                     # ScriptableObject data assets (.asset)
│   │   ├── GameSettings.asset
│   │   ├── PaytableConfig.asset
│   │   ├── SymbolData_Cherry.asset
│   │   ├── SymbolData_Bell.asset
│   │   ├── SymbolData_Bar.asset
│   │   └── SymbolData_Seven.asset
│   ├── Documentation/            # Reference GIF and asset docs
│   ├── Prefabs/                  # Reusable UI & Game Prefabs
│   │   ├── SymbolItem.prefab
│   │   ├── ReelColumn.prefab
│   │   └── WinPopup.prefab
│   ├── Scenes/                   # Unity Scenes
│   │   └── MainSlotScene.unity
│   ├── Scripts/                  # Clean OOP C# Architecture
│   │   ├── Audio/
│   │   │   └── AudioManager.cs
│   │   ├── Bonus/
│   │   │   └── BonusManager.cs
│   │   ├── Core/
│   │   │   ├── GameEvents.cs
│   │   │   ├── SlotGameState.cs
│   │   │   └── SlotMachineController.cs
│   │   ├── Data/
│   │   │   ├── GameSettings.cs
│   │   │   ├── PaytableConfig.cs
│   │   │   ├── SymbolData.cs
│   │   │   └── SymbolType.cs
│   │   ├── Reel/
│   │   │   ├── ReelController.cs
│   │   │   ├── ReelState.cs
│   │   │   └── SymbolItem.cs
│   │   ├── RNG/
│   │   │   ├── IRandomNumberGenerator.cs
│   │   │   ├── SpinOutcome.cs
│   │   │   ├── StandardRNG.cs
│   │   │   └── WeightedRNG.cs
│   │   └── UI/
│   │       ├── HandlePullVisual.cs
│   │       ├── PaytableUI.cs
│   │       ├── UIManager.cs
│   │       └── WinPopupController.cs
│   ├── Sounds/                   # High-Fidelity 16-bit 44.1kHz PCM SFX
│   │   ├── button_click.wav
│   │   ├── handle_pull.wav
│   │   ├── reel_spin.wav
│   │   ├── reel_stop.wav
│   │   ├── win_bell.wav
│   │   ├── win_jackpot.wav
│   │   └── coin_count.wav
│   └── Sprites/                  # Sliced 2D Sprites
│       ├── Buttons/
│       ├── Machine/
│       ├── Symbols/
│       └── UI/
├── Build/
│   └── WebGL/                    # Standalone WebGL Playable Build
│       ├── assets/
│       └── index.html
├── Packages/
│   └── manifest.json             # Unity package dependencies
├── ProjectSettings/              # Project settings & build configurations
├── .gitignore                    # Standard Unity gitignore
├── setup_git_history.ps1         # 1-click script for 11 progressive Git commits
├── setup_git_history.bat         # Windows batch runner for Git setup
└── README.md                     # Project documentation
```

---

## 🛠️ Instructions to Open and Run in Unity Editor

1. Open **Unity Hub**.
2. Click **Add** -> **Add project from disk**.
3. Select the folder: `UnitySlotMachineAssignment`.
4. Open the project with **Unity 2021.3 LTS**, **Unity 2022.3 LTS**, or **Unity 6**.
5. In the Project window, navigate to [`Assets/Scenes/MainSlotScene.unity`](file:///C:/Users/NAKUL SHARMA/.gemini/antigravity/scratch/UnitySlotMachineAssignment/Assets/Scenes/MainSlotScene.unity) and double-click to open.
6. Press the **Play (▶)** button at the top of the editor.
7. Click the **SPIN** button, pull the handle, or press `Spacebar` to spin!

---

## 🚀 Git History & Repository Setup

To satisfy requirement #5 (*"Ensure your Git commit history reflects meaningful progress (avoid one large commit)"*), an automated setup script is provided.

### 1-Click Git Initialization:
Open PowerShell in the project directory and run:
```powershell
.\setup_git_history.ps1
```
*(Or double-click `setup_git_history.bat` on Windows)*.

This initializes Git and creates **11 progressive, meaningful commits**:
1. `chore: initialize Unity project structure and package dependencies`
2. `feat(assets): import slot machine graphics, sliced UI sprites, and procedural audio SFX`
3. `feat(data): implement SymbolData, PaytableConfig, and GameSettings ScriptableObjects`
4. `feat(rng): implement IRandomNumberGenerator strategy with cryptographic StandardRNG and WeightedRNG`
5. `feat(reel): implement ReelController with anticipation wind-up, continuous wrapping, and elastic bounce`
6. `feat(core): implement SlotMachineController state machine, win evaluation, and payout distribution`
7. `feat(bonus): implement Free Spins mode with 2x win multiplier and Wild Seven substitution`
8. `feat(ui): implement HUD displays, bet selection presets, win count-up popup, and AudioManager`
9. `feat(scene): create MainSlotScene with Canvas, Camera, Prefabs, and EventSystem`
10. `build(webgl): add playable WebGL build inside /Build/WebGL`
11. `docs: add comprehensive README with architecture diagrams, math model, and setup instructions`

### Pushing to GitHub:
```bash
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO_NAME>.git
git push -u origin main
```

---

## 💡 Candidate Thought Process & Engineering Approach

1. **Understanding the Problem**:
   - Slot machines look deceptively simple on the surface, but commercial slot games require strict mathematical integrity, zero visual jitter, and gratifying game feel.
2. **Separating Math from Presentation (Server-Authoritative Paradigm)**:
   - In real-world casino engineering, the random outcome must **never** depend on where a visual animation happens to land (client-side physics drift).
   - Instead, the outcome is determined mathematically by the RNG engine **at spin initiation**. The reel controller is then instructed to decelerate onto that specific target symbol.
3. **Designing for Game Feel (Juice)**:
   - Pure linear motion feels robotic. We implemented:
     - *Anticipation*: A brief 150ms upward wind-up recoil that builds kinetic tension.
     - *Staggered stops*: Staggering reel deceleration by 450ms across columns creates escalating suspense.
     - *Damped spring bounce*: An elastic overshoot formula gives the mechanical feeling of heavy reels clicking into physical slot teeth.
     - *Audio synchronization*: Pitch shifts across stops (`Reel 1: 1.0x`, `Reel 2: 1.08x`, `Reel 3: 1.16x`) heighten anticipation for the third reel!
4. **Code Scalability & Maintainability**:
   - Everything is decoupled: adding a 4th or 5th reel only requires passing a new count to `SlotMachineController` and instantiating another prefab.
   - ScriptableObjects allow tuning win multipliers and probabilities without recompiling C# code.
