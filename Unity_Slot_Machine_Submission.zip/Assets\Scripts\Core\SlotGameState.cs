namespace SlotMachine.Core
{
    /// <summary>
    /// Master lifecycle state of the slot machine game loop.
    /// </summary>
    public enum SlotGameState
    {
        Idle,               // Ready for player input (betting, spinning)
        PullingHandle,      // Handle pulling animation playing
        Spinning,           // Reels currently spinning
        StoppingReels,      // Reels stopping in staggered sequence
        EvaluatingWin,      // Checking winning combinations and calculating payout
        CelebratingWin,     // Displaying win popups, coin counting, animations
        BonusRound          // Executing Free Spins bonus sequence
    }
}
