using UnityEngine;

namespace SlotMachine.Data
{
    /// <summary>
    /// ScriptableObject defining visual and mechanical attributes for a slot machine symbol.
    /// Provides data decoupling for easy designer tuning without code modification.
    /// </summary>
    [CreateAssetMenu(fileName = "SymbolData_", menuName = "Slot Machine/Symbol Data", order = 1)]
    public class SymbolData : ScriptableObject
    {
        [Header("Identity")]
        [Tooltip("The unique enum identifier for this symbol.")]
        [SerializeField] private SymbolType _symbolType;

        [Tooltip("Display name used in UI and paytable.")]
        [SerializeField] private string _displayName = "Symbol";

        [Header("Visuals")]
        [Tooltip("The sprite graphic representing this symbol on the reel.")]
        [SerializeField] private Sprite _symbolSprite;

        [Header("Math & Payout")]
        [Tooltip("Base payout multiplier awarded when 3 matching symbols land on the payline.")]
        [SerializeField] private int _threeOfAKindMultiplier = 10;

        [Tooltip("Partial payout multiplier awarded when 2 matching symbols land (from left reel).")]
        [SerializeField] private int _twoOfAKindMultiplier = 0;

        [Tooltip("RNG weight factor used in WeightedRNG to control hit frequency and RTP.")]
        [Range(1, 100)]
        [SerializeField] private int _rngWeight = 25;

        [Header("Bonus Properties")]
        [Tooltip("Whether this symbol acts as a Wild symbol.")]
        [SerializeField] private bool _isWild = false;

        [Tooltip("Whether landing 3 of this symbol triggers the Free Spins bonus mode.")]
        [SerializeField] private bool _triggersBonus = false;

        [Tooltip("Number of free spins awarded if bonus is triggered.")]
        [SerializeField] private int _freeSpinsAwarded = 0;

        // Public getters adhering to encapsulation
        public SymbolType Type => _symbolType;
        public string DisplayName => _displayName;
        public Sprite SymbolSprite => _symbolSprite;
        public int ThreeOfAKindMultiplier => _threeOfAKindMultiplier;
        public int TwoOfAKindMultiplier => _twoOfAKindMultiplier;
        public int RngWeight => _rngWeight;
        public bool IsWild => _isWild;
        public bool TriggersBonus => _triggersBonus;
        public int FreeSpinsAwarded => _freeSpinsAwarded;
    }
}
