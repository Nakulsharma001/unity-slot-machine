using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using SlotMachine.Core;

namespace SlotMachine.UI
{
    /// <summary>
    /// Interactive physical handle on the slot machine.
    /// Can be clicked/pulled directly by the player or triggered programmatically via Spin button.
    /// Animates down and springs back up with mechanical timing.
    /// </summary>
    public class HandlePullVisual : MonoBehaviour, IPointerDownHandler
    {
        [Header("Components")]
        [SerializeField] private Image _handleImage;
        [SerializeField] private SlotMachineController _slotController;

        [Header("Sprites")]
        [Tooltip("Handle in default upright position.")]
        [SerializeField] private Sprite _handleUpSprite;

        [Tooltip("Handle pulled down position.")]
        [SerializeField] private Sprite _handleDownSprite;

        [Header("Animation")]
        [SerializeField] private float _downHoldDuration = 0.18f;

        private bool _isPulling = false;

        private void OnEnable()
        {
            GameEvents.OnHandlePulled += PlayHandlePullAnimation;
        }

        private void OnDisable()
        {
            GameEvents.OnHandlePulled -= PlayHandlePullAnimation;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_slotController != null && _slotController.CanSpin && !_isPulling)
            {
                _slotController.TriggerSpin();
            }
        }

        public void PlayHandlePullAnimation()
        {
            if (!_isPulling)
            {
                StartCoroutine(HandlePullRoutine());
            }
        }

        private IEnumerator HandlePullRoutine()
        {
            _isPulling = true;

            // Switch to pulled down state
            if (_handleImage != null && _handleDownSprite != null)
            {
                _handleImage.sprite = _handleDownSprite;
            }

            yield return new WaitForSeconds(_downHoldDuration);

            // Spring back upright
            if (_handleImage != null && _handleUpSprite != null)
            {
                _handleImage.sprite = _handleUpSprite;
            }

            _isPulling = false;
        }
    }
}
