using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using SlotMachine.Data;

namespace SlotMachine.RNG
{
    /// <summary>
    /// Weighted Random Number Generator implementing cumulative distribution sampling.
    /// Utilizes symbol weights from SymbolData to produce realistic casino slot probabilities
    /// and balanced Return-To-Player (RTP) payout frequency.
    /// </summary>
    public class WeightedRNG : IRandomNumberGenerator
    {
        private readonly RNGCryptoServiceProvider _cryptoProvider = new RNGCryptoServiceProvider();
        private readonly byte[] _randomBuffer = new byte[4];

        private int NextInt(int maxValue)
        {
            if (maxValue <= 0) return 0;
            _cryptoProvider.GetBytes(_randomBuffer);
            uint randUint = BitConverter.ToUInt32(_randomBuffer, 0);
            return (int)(randUint % (uint)maxValue);
        }

        public SymbolData GetRandomSymbol(IReadOnlyList<SymbolData> availableSymbols)
        {
            if (availableSymbols == null || availableSymbols.Count == 0)
                throw new ArgumentException("Available symbols list cannot be null or empty.");

            // Calculate total weight sum
            int totalWeight = 0;
            for (int i = 0; i < availableSymbols.Count; i++)
            {
                totalWeight += availableSymbols[i].RngWeight;
            }

            if (totalWeight <= 0)
            {
                // Fallback to uniform selection if weights are zero or missing
                return availableSymbols[NextInt(availableSymbols.Count)];
            }

            // Sample random weight threshold
            int roll = NextInt(totalWeight);
            int cumulative = 0;

            for (int i = 0; i < availableSymbols.Count; i++)
            {
                cumulative += availableSymbols[i].RngWeight;
                if (roll < cumulative)
                {
                    return availableSymbols[i];
                }
            }

            return availableSymbols[availableSymbols.Count - 1];
        }

        public List<SymbolData> GenerateReelOutcomes(int reelCount, IReadOnlyList<SymbolData> availableSymbols)
        {
            var results = new List<SymbolData>(reelCount);
            for (int i = 0; i < reelCount; i++)
            {
                results.Add(GetRandomSymbol(availableSymbols));
            }
            return results;
        }
    }
}
