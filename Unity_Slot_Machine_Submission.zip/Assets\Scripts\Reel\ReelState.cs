namespace SlotMachine.Reel
{
    /// <summary>
    /// Lifecycle states for an individual spinning reel column.
    /// </summary>
    public enum ReelState
    {
        Idle,
        Anticipation,
        Spinning,
        Stopping,
        OvershootBounce,
        Stopped
    }
}
