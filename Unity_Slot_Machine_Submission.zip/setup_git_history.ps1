# Automated Git History Setup for Unity Slot Machine Assignment
# Creates 11 professional, progressive commits to satisfy:
# "Ensure your Git commit history reflects meaningful progress (avoid one large commit)"

$ErrorActionPreference = "Stop"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "[!] Git is not installed or not in your PATH." -ForegroundColor Yellow
    Write-Host "Please install Git from https://git-scm.com/download/win and rerun this script." -ForegroundColor Yellow
    exit 1
}

Write-Host "=== Initializing Git Repository with Progressive Commit History ===" -ForegroundColor Green

# Remove any existing .git to ensure clean history
if (Test-Path ".git") {
    Remove-Item -Path ".git" -Recurse -Force
}

git init
git branch -M main

# Commit 1: Project Scaffolding
git add .gitignore Packages/ ProjectSettings/
git commit -m "chore: initialize Unity project structure and package dependencies"

# Commit 2: Assets & Audio
git add Assets/Sprites/ Assets/Sounds/ Assets/Documentation/
git commit -m "feat(assets): import slot machine graphics, sliced UI sprites, and procedural audio SFX"

# Commit 3: Data Models & ScriptableObjects
git add Assets/Scripts/Data/ Assets/Data/
git commit -m "feat(data): implement SymbolData, PaytableConfig, and GameSettings ScriptableObjects"

# Commit 4: RNG Engine
git add Assets/Scripts/RNG/
git commit -m "feat(rng): implement IRandomNumberGenerator strategy with cryptographic StandardRNG and WeightedRNG"

# Commit 5: Reel Controller & Physics
git add Assets/Scripts/Reel/
git commit -m "feat(reel): implement ReelController with anticipation wind-up, continuous wrapping, and elastic bounce"

# Commit 6: Core State Machine & Evaluation
git add Assets/Scripts/Core/
git commit -m "feat(core): implement SlotMachineController state machine, win evaluation, and payout distribution"

# Commit 7: Bonus System
git add Assets/Scripts/Bonus/
git commit -m "feat(bonus): implement Free Spins mode with 2x win multiplier and Wild Seven substitution"

# Commit 8: Audio & UI Systems
git add Assets/Scripts/Audio/ Assets/Scripts/UI/
git commit -m "feat(ui): implement HUD displays, bet selection presets, win count-up popup, and AudioManager"

# Commit 9: Scene & Prefabs
git add Assets/Prefabs/ Assets/Scenes/
git commit -m "feat(scene): create MainSlotScene with Canvas, Camera, Prefabs, and EventSystem"

# Commit 10: WebGL Build
git add Build/
git commit -m "build(webgl): add playable WebGL build inside /Build/WebGL"

# Commit 11: Documentation
git add README.md setup_git_history.ps1 setup_git_history.bat
git commit -m "docs: add comprehensive README with architecture diagrams, math model, and setup instructions"

Write-Host "`n[SUCCESS] Git repository initialized with 11 meaningful, professional commits!" -ForegroundColor Green
Write-Host "To push to your public GitHub repository, run:" -ForegroundColor Cyan
Write-Host "  git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO_NAME>.git" -ForegroundColor White
Write-Host "  git push -u origin main" -ForegroundColor White
