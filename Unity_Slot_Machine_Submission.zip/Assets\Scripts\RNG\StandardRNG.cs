using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using SlotMachine.Data;

namespace SlotMachine.RNG
{
    /// <summary>
    /// Pure uniform Random Number Generator backed by System.Security.Cryptography.RNGCryptoServiceProvider.
    /// Provides cryptographic unpredictability with zero bias across all symbols.
    /// </summary>
    public class StandardRNG : IRandomNumberGenerator
    {
        private readonly RNGCryptoServiceProvider _cryptoProvider = new RNGCryptoServiceProvider();
        private readonly byte[] _randomBuffer = new byte[4];

        /// <summary>
        /// Generates an integer in range [0, maxValue) using crypto-safe bytes.
        /// </summary>
        private int NextInt(int maxValue)
        {
            if (maxValue <= 0) return 0;
            _cryptoProvider.GetBytes(_randomBuffer);
            uint randUint = BitConverter.ToUInt32(_randomBuffer, 0);
            return (int)(randUint % (uint)maxValue);
        }

        public SymbolData GetRandomSymbol(IReadOnlyList<SymbolData> availableSymbols)
        {
            if (availableSymbols == null || availableSymbols.Count == 0)
                throw new ArgumentException("Available symbols list cannot be null or empty.");

            int index = NextInt(availableSymbols.Count);
            return availableSymbols[index];
        }

        public List<SymbolData> GenerateReelOutcomes(int reelCount, IReadOnlyList<SymbolData> availableSymbols)
        {
            var results = new List<SymbolData>(reelCount);
            for (int i = 0; i < reelCount; i++)
            {
                results.Add(GetRandomSymbol(availableSymbols));
            }
            return results;
        }
    }
}
