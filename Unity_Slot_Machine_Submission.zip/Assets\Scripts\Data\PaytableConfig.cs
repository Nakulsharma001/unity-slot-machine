using System.Collections.Generic;
using UnityEngine;

namespace SlotMachine.Data
{
    /// <summary>
    /// Configuration asset containing the registered symbols, paytable multipliers,
    /// and win evaluation rules.
    /// </summary>
    [CreateAssetMenu(fileName = "PaytableConfig", menuName = "Slot Machine/Paytable Config", order = 2)]
    public class PaytableConfig : ScriptableObject
    {
        [Header("Registered Symbols")]
        [Tooltip("List of all active symbol data configurations.")]
        [SerializeField] private List<SymbolData> _symbols = new List<SymbolData>();

        [Header("Global Win Rules")]
        [Tooltip("Minimum consecutive matches required for a win (standard 3-reel is 3).")]
        [SerializeField] private int _requiredMatchesForWin = 3;

        [Tooltip("Multiplier applied during Bonus / Free Spins rounds.")]
        [SerializeField] private float _bonusWinMultiplier = 2.0f;

        public IReadOnlyList<SymbolData> Symbols => _symbols;
        public int RequiredMatchesForWin => _requiredMatchesForWin;
        public float BonusWinMultiplier => _bonusWinMultiplier;

        /// <summary>
        /// Retrieves the SymbolData matching a specific SymbolType.
        /// </summary>
        public SymbolData GetSymbolData(SymbolType type)
        {
            for (int i = 0; i < _symbols.Count; i++)
            {
                if (_symbols[i].Type == type)
                    return _symbols[i];
            }
            return null;
        }
    }
}
