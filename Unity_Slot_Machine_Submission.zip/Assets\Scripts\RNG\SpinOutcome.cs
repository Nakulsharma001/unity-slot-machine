using System.Collections.Generic;
using SlotMachine.Data;

namespace SlotMachine.RNG
{
    /// <summary>
    /// Encapsulates the complete mathematical outcome of a single spin event.
    /// Calculated deterministically before or at spin initiation (Server-Authoritative style).
    /// </summary>
    public class SpinOutcome
    {
        /// <summary>
        /// The target symbol landing on the central payline for each reel (Index 0 = Reel 1, 1 = Reel 2, 2 = Reel 3).
        /// </summary>
        public List<SymbolData> ReelResults { get; }

        /// <summary>
        /// Whether this spin produced a winning combination.
        /// </summary>
        public bool IsWin { get; set; }

        /// <summary>
        /// The winning symbol data if a win was achieved; otherwise null.
        /// </summary>
        public SymbolData WinningSymbol { get; set; }

        /// <summary>
        /// The payout multiplier factor achieved (e.g. 10x, 50x, 100x).
        /// </summary>
        public int PayoutMultiplier { get; set; }

        /// <summary>
        /// Total credit payout calculated as (Bet * PayoutMultiplier * BonusMultiplier).
        /// </summary>
        public int TotalPayout { get; set; }

        /// <summary>
        /// True if this spin triggers the Bonus / Free Spins round.
        /// </summary>
        public bool TriggeredFreeSpins { get; set; }

        /// <summary>
        /// Number of free spins awarded.
        /// </summary>
        public int FreeSpinsCount { get; set; }

        /// <summary>
        /// True if this outcome achieved the highest Jackpot tier (3x Sevens).
        /// </summary>
        public bool IsJackpot { get; set; }

        public SpinOutcome(List<SymbolData> reelResults)
        {
            ReelResults = reelResults ?? new List<SymbolData>();
            IsWin = false;
            WinningSymbol = null;
            PayoutMultiplier = 0;
            TotalPayout = 0;
            TriggeredFreeSpins = false;
            FreeSpinsCount = 0;
            IsJackpot = false;
        }
    }
}
