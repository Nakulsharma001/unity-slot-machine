using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using SlotMachine.Data;

namespace SlotMachine.Reel
{
    /// <summary>
    /// Represents an individual visual symbol cell on a reel strip.
    /// Manages sprite swapping, highlight states, and winning animation pulses.
    /// </summary>
    public class SymbolItem : MonoBehaviour
    {
        [Header("Components")]
        [Tooltip("The UI Image component rendering the symbol sprite.")]
        [SerializeField] private Image _symbolImage;

        [Tooltip("Optional glow or highlight border activated upon win.")]
        [SerializeField] private Image _highlightBorder;

        private RectTransform _rectTransform;
        private SymbolData _currentData;
        private Coroutine _pulseCoroutine;
        private Vector3 _originalScale = Vector3.one;

        public RectTransform RectTransform => _rectTransform;
        public SymbolData CurrentData => _currentData;

        private void Awake()
        {
            _rectTransform = GetComponent<RectTransform>();
            if (_symbolImage == null)
            {
                _symbolImage = GetComponent<Image>();
            }
            if (_highlightBorder != null)
            {
                _highlightBorder.gameObject.SetActive(false);
            }
            _originalScale = _rectTransform != null ? _rectTransform.localScale : Vector3.one;
        }

        /// <summary>
        /// Updates this cell with a new symbol sprite and data model.
        /// </summary>
        public void SetSymbol(SymbolData data)
        {
            _currentData = data;
            if (_symbolImage != null && data != null)
            {
                _symbolImage.sprite = data.SymbolSprite;
                _symbolImage.enabled = true;
            }
        }

        /// <summary>
        /// Highlights or un-highlights the symbol when part of a winning payline.
        /// </summary>
        public void SetHighlight(bool isHighlighted)
        {
            if (_highlightBorder != null)
            {
                _highlightBorder.gameObject.SetActive(isHighlighted);
            }

            if (isHighlighted)
            {
                if (_pulseCoroutine != null) StopCoroutine(_pulseCoroutine);
                _pulseCoroutine = StartCoroutine(AnimateWinPulse());
            }
            else
            {
                if (_pulseCoroutine != null)
                {
                    StopCoroutine(_pulseCoroutine);
                    _pulseCoroutine = null;
                }
                if (_rectTransform != null)
                {
                    _rectTransform.localScale = _originalScale;
                }
            }
        }

        /// <summary>
        /// Pulsing scale animation to create juicy feedback during win celebration.
        /// </summary>
        private IEnumerator AnimateWinPulse()
        {
            float timer = 0f;
            float duration = 0.6f;
            while (true)
            {
                timer += Time.deltaTime;
                float progress = Mathf.PingPong(timer / duration, 1.0f);
                float scale = Mathf.Lerp(1.0f, 1.25f, Mathf.SmoothStep(0f, 1f, progress));
                if (_rectTransform != null)
                {
                    _rectTransform.localScale = _originalScale * scale;
                }
                yield return null;
            }
        }
    }
}
