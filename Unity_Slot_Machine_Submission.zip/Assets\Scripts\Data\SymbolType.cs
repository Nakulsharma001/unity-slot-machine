namespace SlotMachine.Data
{
    /// <summary>
    /// Identifies the classic slot machine symbols.
    /// Order reflects value progression from low-tier to highest jackpot symbol.
    /// </summary>
    public enum SymbolType
    {
        Cherry = 0,
        Bell = 1,
        Bar = 2,
        Seven = 3
    }
}
