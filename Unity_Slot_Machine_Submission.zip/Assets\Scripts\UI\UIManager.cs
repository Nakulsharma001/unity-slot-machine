using UnityEngine;
using UnityEngine.UI;
using SlotMachine.Audio;
using SlotMachine.Core;

namespace SlotMachine.UI
{
    /// <summary>
    /// Master UI manager controlling HUD values, button interactability,
    /// bet selection presets, and free spin status banners.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("Controller Reference")]
        [SerializeField] private SlotMachineController _slotController;

        [Header("HUD Text Displays")]
        [SerializeField] private Text _balanceText;
        [SerializeField] private Text _betText;
        [SerializeField] private Text _winText;
        [SerializeField] private Text _statusBannerText;

        [Header("Interactive Buttons")]
        [SerializeField] private Button _spinButton;
        [SerializeField] private Button _betPlusButton;
        [SerializeField] private Button _betMinusButton;
        [SerializeField] private Button _bet10PresetButton;
        [SerializeField] private Button _bet50PresetButton;
        [SerializeField] private Button _bet100PresetButton;
        [SerializeField] private Button _exitButton;

        [Header("Exit Modal")]
        [SerializeField] private GameObject _exitModal;
        [SerializeField] private Button _confirmExitButton;
        [SerializeField] private Button _cancelExitButton;

        private void Awake()
        {
            RegisterButtonCallbacks();
            if (_exitModal != null) _exitModal.SetActive(false);
            if (_statusBannerText != null) _statusBannerText.gameObject.SetActive(false);
        }

        private void RegisterButtonCallbacks()
        {
            if (_spinButton != null)
            {
                _spinButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.TriggerSpin();
                });
            }

            if (_betPlusButton != null)
            {
                _betPlusButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.IncreaseBet();
                });
            }

            if (_betMinusButton != null)
            {
                _betMinusButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.DecreaseBet();
                });
            }

            // Direct preset buttons (from reference design GIF)
            if (_bet10PresetButton != null)
            {
                _bet10PresetButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.SetBetDirect(10);
                });
            }

            if (_bet50PresetButton != null)
            {
                _bet50PresetButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.SetBetDirect(50);
                });
            }

            if (_bet100PresetButton != null)
            {
                _bet100PresetButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_slotController != null) _slotController.SetBetDirect(100);
                });
            }

            if (_exitButton != null)
            {
                _exitButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_exitModal != null) _exitModal.SetActive(true);
                });
            }

            if (_confirmExitButton != null)
            {
                _confirmExitButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
#if UNITY_EDITOR
                    UnityEditor.EditorApplication.isPlaying = false;
#else
                    Application.Quit();
#endif
                });
            }

            if (_cancelExitButton != null)
            {
                _cancelExitButton.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayButtonClick();
                    if (_exitModal != null) _exitModal.SetActive(false);
                });
            }
        }

        private void OnEnable()
        {
            GameEvents.OnBalanceUpdated += UpdateBalanceDisplay;
            GameEvents.OnBetUpdated += UpdateBetDisplay;
            GameEvents.OnWinAmountUpdated += UpdateWinDisplay;
            GameEvents.OnControlsStateChanged += SetControlsInteractable;
            GameEvents.OnFreeSpinsAwarded += HandleFreeSpinsAwarded;
            GameEvents.OnFreeSpinStarted += HandleFreeSpinTurn;
            GameEvents.OnFreeSpinsCompleted += HandleFreeSpinsCompleted;
        }

        private void OnDisable()
        {
            GameEvents.OnBalanceUpdated -= UpdateBalanceDisplay;
            GameEvents.OnBetUpdated -= UpdateBetDisplay;
            GameEvents.OnWinAmountUpdated -= UpdateWinDisplay;
            GameEvents.OnControlsStateChanged -= SetControlsInteractable;
            GameEvents.OnFreeSpinsAwarded -= HandleFreeSpinsAwarded;
            GameEvents.OnFreeSpinStarted -= HandleFreeSpinTurn;
            GameEvents.OnFreeSpinsCompleted -= HandleFreeSpinsCompleted;
        }

        private void UpdateBalanceDisplay(int newBalance)
        {
            if (_balanceText != null)
            {
                _balanceText.text = $"{newBalance:N0} G";
            }
        }

        private void UpdateBetDisplay(int newBet)
        {
            if (_betText != null)
            {
                _betText.text = $"BET {newBet}G";
            }
        }

        private void UpdateWinDisplay(int winAmount)
        {
            if (_winText != null)
            {
                _winText.text = winAmount > 0 ? $"WIN: {winAmount:N0} G" : "WIN: 0 G";
            }
        }

        private void SetControlsInteractable(bool isInteractable)
        {
            if (_spinButton != null) _spinButton.interactable = isInteractable;
            if (_betPlusButton != null) _betPlusButton.interactable = isInteractable;
            if (_betMinusButton != null) _betMinusButton.interactable = isInteractable;
            if (_bet10PresetButton != null) _bet10PresetButton.interactable = isInteractable;
            if (_bet50PresetButton != null) _bet50PresetButton.interactable = isInteractable;
            if (_bet100PresetButton != null) _bet100PresetButton.interactable = isInteractable;
        }

        private void HandleFreeSpinsAwarded(int totalSpins)
        {
            if (_statusBannerText != null)
            {
                _statusBannerText.gameObject.SetActive(true);
                _statusBannerText.text = $"★ FREE SPINS: {totalSpins} REMAINING (2X WINS) ★";
            }
        }

        private void HandleFreeSpinTurn(int remainingSpins)
        {
            if (_statusBannerText != null)
            {
                _statusBannerText.gameObject.SetActive(true);
                _statusBannerText.text = $"★ FREE SPINS: {remainingSpins} REMAINING (2X WINS) ★";
            }
        }

        private void HandleFreeSpinsCompleted(int totalBonusWin)
        {
            if (_statusBannerText != null)
            {
                _statusBannerText.text = $"BONUS ROUND COMPLETE! WON {totalBonusWin:N0} G";
                Invoke(nameof(HideStatusBanner), 3.0f);
            }
        }

        private void HideStatusBanner()
        {
            if (_statusBannerText != null)
            {
                _statusBannerText.gameObject.SetActive(false);
            }
        }
    }
}
